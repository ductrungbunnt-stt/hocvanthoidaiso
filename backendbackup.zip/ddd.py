import datetime
print(datetime.datetime.now())  # Nếu lỗi thì có xung đột module
